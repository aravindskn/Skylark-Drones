go to index.html
press submit to move to next page(for all pages)

note: data is stored till the browser window is not closed.
